export class MapScroller {
    private canvas: HTMLCanvasElement;
    private image: HTMLImageElement;
    private offsetX: number = 0;
    private offsetY: number = 0;
    private readonly scrollSpeed: number = 7;
    private readonly edgeThreshold: number = 10;

    private mouseX: number = 0;
    private mouseY: number = 0;
    private isMouseInEdge: boolean = false;
    private scrollInterval: number | null = null;

    constructor(canvas: HTMLCanvasElement, image: HTMLImageElement) {
        this.canvas = canvas;
        this.image = image;

        this.setupMouseScrolling();
    }

    private setupMouseScrolling() {
        this.canvas.addEventListener("mousemove", (event) => {
            this.mouseX = event.offsetX;
            this.mouseY = event.offsetY;
            this.checkMousePosition();
        });

        this.canvas.addEventListener("mouseleave", () => {
            this.isMouseInEdge = false;
            if (this.scrollInterval) {
                clearInterval(this.scrollInterval);
                this.scrollInterval = null;
            }
        });
    }

    private checkMousePosition() {
        const inLeftEdge = this.mouseX < this.edgeThreshold;
        const inRightEdge = this.mouseX > this.canvas.width - this.edgeThreshold;
        const inTopEdge = this.mouseY < this.edgeThreshold;
        const inBottomEdge = this.mouseY > this.canvas.height - this.edgeThreshold;

        this.isMouseInEdge = inLeftEdge || inRightEdge || inTopEdge || inBottomEdge;

        if (this.isMouseInEdge && !this.scrollInterval) {
            this.startScrolling();
        }
    }

    private startScrolling() {
        this.scrollInterval = window.setInterval(() => {
            if (this.mouseX < this.edgeThreshold) {
                this.offsetX = Math.max(this.offsetX - this.scrollSpeed, 0);
            } else if (this.mouseX > this.canvas.width - this.edgeThreshold) {
                this.offsetX = Math.min(this.offsetX + this.scrollSpeed, this.image.width - this.canvas.width);
            }

            if (this.mouseY < this.edgeThreshold) {
                this.offsetY = Math.max(this.offsetY - this.scrollSpeed, 0);
            } else if (this.mouseY > this.canvas.height - this.edgeThreshold) {
                this.offsetY = Math.min(this.offsetY + this.scrollSpeed, this.image.height - this.canvas.height);
            }

            if (!this.isMouseInEdge) {
                if (this.scrollInterval) {
                    clearInterval(this.scrollInterval);
                    this.scrollInterval = null;
                }
            }
        }, 16);
    }

    public getOffsetX() {
        return this.offsetX;
    }

    public getOffsetY() {
        return this.offsetY;
    }
}
