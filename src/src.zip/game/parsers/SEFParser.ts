/** Общий тип для координат в тайлах */
export interface TilePosition {
    x: number;
    y: number;
}

export type Direction = 'LEFT' | 'RIGHT' | 'UP' | 'DOWN' | 'UP_LEFT' | 'UP_RIGHT' | 'DOWN_LEFT' | 'DOWN_RIGHT';

export type RouteType = 'STAY' | 'RANDOM_RADIUS' | 'STAY_ROTATE' | 'MOVED_FLIP' | 'MOVED' | 'RANDOM';

/** NPC (персонажи) */
export interface SEFPerson {
    name: string;
    position: TilePosition;
    literaryName?: number;
    direction: Direction;
    routeType?: RouteType;
    route?: string;
    radius?: number;
    delayMin?: number;
    delayMax?: number;
    tribe?: string;
    scriptDialog?: string;
    scriptInventory?: string;
}

/** Входные точки */
export interface SEFPointEntrance {
    name: string;
    direction: Direction;
    position: TilePosition;
}

/** Группы клеток (ключ - название группы, значение - массив позиций) */
export interface SEFCellGroups {
    [groupName: string]: TilePosition[];
}

/** Триггеры */
export interface SEFTrigger {
    name: string;
    literaryName?: number;
    cursorName?: string;
    scriptName?: string;
    inventoryName?: string;
    cellsName?: string;
    isActive?: boolean;
    isVisible?: boolean;
    isTransition?: boolean;
}

/** Основная структура данных SEF */
export interface SEFData {
    version?: string;
    pack: string;
    internalLocation?: boolean;
    exitToGlobalMap?: boolean;
    weather?: number;
    persons: SEFPerson[];
    pointsEntrance: SEFPointEntrance[];
    cellGroups: SEFCellGroups;
    triggers: SEFTrigger[];
}

const fieldMapping: Record<string, keyof SEFPerson | keyof SEFPointEntrance | keyof SEFTrigger> = {
    "position": "position",
    "direction": "direction",
    "route_type": "routeType",
    "cursor_name": "cursorName",
    "script_name": "scriptName",
    "inv_name": "inventoryName",
    "cells_name": "cellsName",
    "route": "route",
    "tribe": "tribe",
    "scr_inv": "scriptInventory",
    "scr_dialog": "scriptDialog",
    "is_active": "isActive",
    "is_visible": "isVisible",
    "is_transition": "isTransition",
    "radius": "radius",
    "delay_min": "delayMin",
    "delay_max": "delayMax",
    "literary_name": "literaryName",
};

const getValueFromStringedString = (string: string) => string.replace(/"/g, "")

export class SEFParser {
    private data: SEFData = {
        persons: [],
        pointsEntrance: [],
        cellGroups: {},
        triggers: []
    };

    constructor(sefText: string) {
        this.parse(sefText);
    }

    private parse(sefText: string) {
        const lines = sefText.split("\n");
        let currentCategory: keyof SEFData | null = null;
        let currentGroupName: string | null = null;
        let insideTrigger: boolean = false;
        let currentObject: any = null;

        lines.forEach(line => {
            const trimmed = line.trim();

            // Читаем основные параметры уровня
            if (trimmed.startsWith("version:")) {
                this.data.version = trimmed.split(":")[1].trim();
            } else if (trimmed.startsWith("pack:")) {
                this.data.pack = trimmed.split(":")[1].trim().replace(/"/g, "").toLowerCase();
            } else if (trimmed.startsWith("internal_location:")) {
                this.data.internalLocation = trimmed.split(":")[1].trim() === '1';
            } else if (trimmed.startsWith("exit_to_globalmap:")) {
                this.data.exitToGlobalMap = trimmed.split(":")[1].trim() === '1';
            } else if (trimmed.startsWith("weather:")) {
                this.data.weather = parseInt(trimmed.split(":")[1].trim());
            }

            // Определяем категорию
            if (trimmed.startsWith("persons") || trimmed.startsWith("points_entrance") ||
                trimmed.startsWith("cell_groups") || trimmed.startsWith("triggers")) {

                if (currentObject && currentCategory) {
                    this.addObjectToCategory(currentCategory, currentObject);
                }

                currentCategory = trimmed.split(":")[0] as keyof SEFData;
                currentGroupName = null;
                currentObject = null;
            }

            // Начало нового объекта
            if (trimmed.startsWith("name:")) {
                if (currentObject && currentCategory) {
                    this.addObjectToCategory(currentCategory, currentObject);
                }

                const objName = trimmed.split(":")[1].trim().replace(/"/g, "");

                if (currentCategory === "cell_groups") {
                    this.data.cellGroups[objName] = [];
                    currentGroupName = objName;
                } else if (currentCategory === "triggers") {
                    currentObject = { name: objName };
                    insideTrigger = true;
                } else if (currentCategory === "persons") {
                    currentObject = { name: objName, position: { x: 0, y: 0 }, direction: "DOWN" };
                } else if (currentCategory === "points_entrance") {
                    currentObject = { name: objName, position: { x: 0, y: 0 }, direction: "DOWN" };
                }
            }

            // Закрытие блока триггера
            if (trimmed.startsWith("}")) {
                insideTrigger = false;
            }

            // Запись данных внутрь объекта
            const [fieldName, ...values] = trimmed.split(/\s+/);
            const camelCaseFieldName = fieldMapping[fieldName] || fieldName; // Если нет в маппинге, оставляем как есть

            switch (camelCaseFieldName) {
                case "position":
                    if (values.length > 1 && currentObject) {
                        currentObject.position = { x: parseInt(values[0]), y: parseInt(values[1]) };
                    }
                    break;

                case "direction":
                    if (values[0] && currentObject) {
                        currentObject.direction = getValueFromStringedString(values[0]) as Direction;
                    }
                    break;

                case "routeType":
                    if (values[0] && currentObject) {
                        currentObject.routeType = getValueFromStringedString(values[0]) as RouteType;
                    }
                    break;

                case "cursorName":
                case "scriptName":
                case "inventoryName":
                case "cellsName":
                case "route":
                case "tribe":
                case "scriptInventory":
                case "scriptDialog":
                    if (values[0] && currentObject) {
                        currentObject[camelCaseFieldName] = getValueFromStringedString(values[0]);
                    }
                    break;

                case "isActive":
                case "isVisible":
                case "isTransition":
                    if (values[0] && currentObject) {
                        currentObject[camelCaseFieldName] = values[0] === "1";
                    }
                    break;

                case "radius":
                case "delayMin":
                case "delayMax":
                case "literaryName":
                    if (values[0] && currentObject) {
                        currentObject[camelCaseFieldName] = parseInt(values[0]);
                    }
                    break;

                default:
                    // Проверяем cell_groups (cell_00, cell_01 и т.д.)
                    if (currentCategory === "cell_groups" && currentGroupName && fieldName.startsWith("cell_")) {
                        if (values.length > 1) {
                            this.data.cellGroups[currentGroupName].push({ x: parseInt(values[0]), y: parseInt(values[1]) });
                        }
                    }
                    break;
            }
        });

        // Добавляем последний объект
        if (currentObject && currentCategory) {
            this.addObjectToCategory(currentCategory, currentObject);
        }

        console.log("Parsed SEF Data:", this.data);
    }

    private addObjectToCategory(category: keyof SEFData, obj: any) {
        if (category === "persons") {
            this.data.persons.push(obj as SEFPerson);
        } else if (category === "points_entrance") {
            this.data.pointsEntrance.push(obj as SEFPointEntrance);
        } else if (category === "cell_groups") {
            this.data.cellGroups[obj.name] = obj.cells;
        } else if (category === "triggers") {
            this.data.triggers.push(obj as SEFTrigger);
        }
    }

    public getData() {
        return this.data;
    }
}
