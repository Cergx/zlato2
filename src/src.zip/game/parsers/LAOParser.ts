import { Animation } from "../Animation.ts";
import { Paths } from "../../constants/Paths.ts";

export class LAOParser {
    private animations: Animation[] = [];

    constructor(filePath: string, levelString: string) {
        this.loadFile(filePath, levelString);
    }

    private async loadFile(filePath: string, levelString: string): Promise<void> {
        console.log(filePath);
        const response = await fetch(filePath);
        const buffer = await response.arrayBuffer();
        console.log('buffer', buffer);
        this.parse(buffer, levelString);
    }

    private parse(buffer: ArrayBuffer, levelString: string): void {
        const recordSize = 8;

        if (buffer.byteLength%recordSize !== 0 || buffer.byteLength > 500) {
            return;
        }
        const view = new DataView(buffer);

        for (let i = 0; i < buffer.byteLength; i += recordSize) {
            const frameHeight = view.getUint16(i, true);
            const frameDuration = view.getUint16(i + 4, true);
            this.animations.push(new Animation(Paths.LEVEL_ANIMATION(levelString, i / recordSize), frameHeight, frameDuration));
        }
    }

    getAnimations(): Animation[] {
        return this.animations;
    }
}
