import { loadCSX } from "./Assets.ts";
import { MapRenderer } from "./MapRenderer";
import { SDBParser } from "./parsers/SDBParser.ts";
import { SEFParser } from "./parsers/SEFParser.ts";
import { Paths } from "../constants/paths.ts";
import { LAOParser } from "./parsers/LAOParser.ts";
import { LevelType } from "../constants/levels.ts";

export const initGame = async (canvas: HTMLCanvasElement) => {
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const level = 'l1_1_1';
    const levelType: LevelType = 'single';

    // Загружаем SEF-файл
    const sefText = await fetch(Paths.LEVEL_SEF(level, levelType)).then(res => res.text());
    const sefParser = new SEFParser(sefText);
    const sefData = sefParser.getData();

    // Загружаем SDB-файл
    const sdbData = await fetch(Paths.LEVEL_SDB(level, levelType)).then(res => res.arrayBuffer());
    const sdbParser = new SDBParser(sdbData);

    // Загружаем изображение карты
    const mapImage = new Image();
    mapImage.src = Paths.LEVEL_IMAGE(sefData.pack);
    await new Promise((resolve) => (mapImage.onload = resolve));

    // Загружаем анимации
    const animations = new LAOParser(Paths.LEVEL_LAO(sefData.pack), sefData.pack).getAnimations();
    const mask_4 = await loadCSX(`/assets/levels/pack/${level}/bitmaps/masks/mask_4.csx`);

    // Создаём MapRenderer с готовыми данными
    const mapRenderer = new MapRenderer(canvas, mapImage, sdbParser, sefData);

    const TARGET_FPS = 60;
    const FRAME_DURATION = 1000 / TARGET_FPS;
    let lastFrameTime = performance.now();

    const gameLoop = () => {
        requestAnimationFrame(gameLoop);

        const now = performance.now();
        const deltaTime = now - lastFrameTime;
        if (deltaTime < FRAME_DURATION) return;

        lastFrameTime = now - (deltaTime % FRAME_DURATION);

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Отрисовываем карту
        mapRenderer.drawMap();

        // Отрисовываем анимации
        animations.forEach((animation, index) => {
            animation.update();
            animation.draw(ctx, 100, index*100);
        });

        if (mask_4) {
            ctx.drawImage(mask_4, 300, 100);
        }
    };

    gameLoop();
};
