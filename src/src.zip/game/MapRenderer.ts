import { SDBParser } from "./parsers/SDBParser.ts";
import { SEFData } from "./parsers/SEFParser.ts";
import { MapScroller } from "./MapScroller";

export class MapRenderer {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D | null;
    private image: HTMLImageElement;
    private sdbParser: SDBParser;
    private sefData: SEFData;
    private scroller: MapScroller | null = null;

    private readonly tileWidth: number = 12;
    private readonly tileHeight: number = 9;

    constructor(canvas: HTMLCanvasElement, image: HTMLImageElement, sdbParser: SDBParser, sefData: SEFData) {
        this.canvas = canvas;
        this.ctx = canvas.getContext("2d");
        this.image = image;
        this.sdbParser = sdbParser;
        this.sefData = sefData;

        // Создаём MapScroller
        this.scroller = new MapScroller(this.canvas, this.image);
    }

    public drawMap() {
        if (!this.ctx || !this.image || !this.sdbParser || !this.scroller) return;

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        const offsetX = this.scroller.getOffsetX();
        const offsetY = this.scroller.getOffsetY();

        this.ctx.drawImage(this.image, offsetX, offsetY, this.canvas.width, this.canvas.height, 0, 0, this.canvas.width, this.canvas.height);

        // Отрисовываем сетку тайлов
        this.drawGrid();

        // Отрисовываем NPC (persons)
        this.drawPersons(this.sefData.persons, "red");

        // Отрисовываем входные точки (pointsEntrance)
        this.drawPointsEntrance(this.sefData.pointsEntrance, "blue");

        // Отрисовываем `cellGroups`
        this.drawCellGroups(this.sefData.cellGroups, "green");
    }

    private drawGrid() {
        if (!this.ctx) return;

        const cols = Math.ceil(this.canvas.width / this.tileWidth);
        const rows = Math.ceil(this.canvas.height / this.tileHeight);

        this.ctx.strokeStyle = "red"; // Цвет сетки
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([4, 4]); // Штрихпунктирная линия
        this.ctx.globalAlpha = 0; // Полупрозрачность

        this.ctx.beginPath();

        // Вертикальные линии
        for (let col = 0; col <= cols; col++) {
            const x = col * this.tileWidth;
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.canvas.height);
        }

        // Горизонтальные линии
        for (let row = 0; row <= rows; row++) {
            const y = row * this.tileHeight;
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.canvas.width, y);
        }

        this.ctx.stroke();
        this.ctx.setLineDash([]);
        this.ctx.globalAlpha = 1;
    }

    private drawPersons(persons: SEFData["persons"], color: string) {
        if (!this.ctx) return;

        const offsetX = this.scroller!.getOffsetX();
        const offsetY = this.scroller!.getOffsetY();

        persons.forEach(person => {
            const name = person.literaryName ? this.sdbParser.getName(person.literaryName) : person.name;
            const objX = person.position.x * this.tileWidth - offsetX;
            const objY = person.position.y * this.tileHeight - offsetY;

            this.drawPoint(objX, objY, 5, color, name);
        });
    }

    private drawPointsEntrance(points: SEFData["pointsEntrance"], color: string) {
        if (!this.ctx) return;

        const offsetX = this.scroller!.getOffsetX();
        const offsetY = this.scroller!.getOffsetY();

        points.forEach(point => {
            const name = point.name;
            const objX = point.position.x * this.tileWidth - offsetX;
            const objY = point.position.y * this.tileHeight - offsetY;

            this.drawPoint(objX, objY, 4, color, name);
        });
    }

    private drawCellGroups(cellGroups: SEFData["cellGroups"], color: string) {
        if (!this.ctx) return;

        const offsetX = this.scroller!.getOffsetX();
        const offsetY = this.scroller!.getOffsetY();

        Object.entries(cellGroups).forEach(([groupName, positions]) => {
            if (positions.length === 0) return;

            this.ctx!.strokeStyle = color;
            this.ctx!.lineWidth = 2;
            this.ctx!.beginPath();

            positions.forEach((pos, index) => {
                const objX = pos.x * this.tileWidth - offsetX;
                const objY = pos.y * this.tileHeight - offsetY;

                if (index === 0) {
                    this.ctx!.moveTo(objX, objY);
                    this.drawPoint(objX, objY, 3, color, groupName);
                } else {
                    this.ctx!.lineTo(objX, objY);
                }
            });

            if (positions.length > 2) {
                const first = positions[0];
                this.ctx!.lineTo(first.x * this.tileWidth - offsetX, first.y * this.tileHeight - offsetY);
            }

            this.ctx!.stroke();
        });
    }

    private drawPoint(x: number, y: number, size: number, color: string, label?: string) {
        if (!this.ctx) return;

        this.ctx!.fillStyle = color;
        this.ctx!.beginPath();
        this.ctx!.arc(x, y, size, 0, Math.PI * 2);
        this.ctx!.fill();

        if (label) {
            this.ctx!.fillStyle = "white";
            this.ctx!.font = "12px Arial";
            this.ctx!.fillText(label, x + 5, y - 5);
        }
    }
}
