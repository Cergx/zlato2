import { useEffect, useRef } from "react";
import { initGame } from "../../game/Game";
import { useCursor } from "../../context/CursorContext";
import { CursorType } from "../../enum/CursorTypes.ts";
import styles from "./GameWindow.module.scss";

export const GameWindow = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const isInitialized = useRef(false);
    const { setCursor } = useCursor(); // Получаем setCursor из контекста

    useEffect(() => {
        if (!isInitialized.current && canvasRef.current) {
            initGame(canvasRef.current);
            isInitialized.current = true;
            setCursor(CursorType.CANT_CAST);
        }
    }, []);

    return (
        <div className={styles.gameWindow}>
            <canvas width={1240} height={1024} ref={canvasRef} />
        </div>
    );
};
