import { createContext, useContext, useEffect, useState } from "react";
import { ANIParser } from "../game/parsers/ANIParser.ts";
import { CursorType } from "../types/CursorTypes";

interface CursorContextType {
    setCursor: (cursor: CursorType) => void;
}

const CursorContext = createContext<CursorContextType | undefined>(undefined);

export const useCursor = () => {
    const context = useContext(CursorContext);
    if (!context) {
        throw new Error("useCursor must be used within a CursorProvider");
    }
    return context;
};

export const CursorProvider = ({ children }: { children: React.ReactNode }) => {
    const [cursorFrames, setCursorFrames] = useState<string[]>([]);
    const [frameIndex, setFrameIndex] = useState(0);
    const [frameDelays, setFrameDelays] = useState<number[]>([]);
    const [isAnimating, setIsAnimating] = useState(false);

    const setCursor = async (cursor: CursorType) => {
        const path = `/assets/cursors/${cursor}`;
        try {
            const response = await fetch(path);
            const buffer = await response.arrayBuffer();
            const aniParser = new ANIParser(buffer);
            const aniData = aniParser.parse();

            if (aniData.images.length > 0) {
                const frames = aniData.images.map((image) => {
                    const blob = new Blob([image], { type: "image/x-icon" });
                    return URL.createObjectURL(blob);
                });

                const delays = aniData.rate.length > 0 ? aniData.rate.map((r) => r * 15) : [100];

                setCursorFrames(frames);
                setFrameDelays(delays);
                setIsAnimating(frames.length > 1);
            }
        } catch (error) {
            console.error("Failed to load ANI cursor:", error);
        }
    };

    useEffect(() => {
        let timeoutId: NodeJS.Timeout;

        const animateCursor = () => {
            setFrameIndex((prevIndex) => (prevIndex + 1) % cursorFrames.length);
            const delay = frameDelays[frameIndex] ?? 100;
            timeoutId = setTimeout(animateCursor, delay);
        };

        if (isAnimating && cursorFrames.length > 1) {
            timeoutId = setTimeout(animateCursor, frameDelays[frameIndex] ?? 100);
        }

        return () => {
            clearTimeout(timeoutId);
        };
    }, [cursorFrames, frameDelays, isAnimating, frameIndex]);

    return (
        <CursorContext.Provider value={{ setCursor }}>
            <div style={{ cursor: cursorFrames[frameIndex] ? `url(${cursorFrames[frameIndex]}), auto` : "auto" }}>
                {children}
            </div>
        </CursorContext.Provider>
    );
};
