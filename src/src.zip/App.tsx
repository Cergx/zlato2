import { CursorProvider } from "./context/CursorContext";
import styles from "./App.module.scss";
import { GameWindow } from "./components/gameWindow/GameWindow";

export const App = () => {
    return (
        <CursorProvider>
        <div className={styles.container}>
            <h1>Злато 2</h1>
            <GameWindow />
        </div>
        </CursorProvider>
    );
};

export default App;
