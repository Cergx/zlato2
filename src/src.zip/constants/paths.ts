import { LevelType } from "./levels.ts";

export const AssetsBase = "/assets";

export const Paths = {
    CURSORS: `${AssetsBase}/cursors`,
    ENGINERES: `${AssetsBase}/engineres`,
    ITEMS: `${AssetsBase}/items`,
    LEVELS: `${AssetsBase}/levels`,
    MAGIC: `${AssetsBase}/magic`,
    MUSIC: `${AssetsBase}/music`,
    PERSONS: `${AssetsBase}/persons`,
    SCRIPTS: `${AssetsBase}/scripts`,
    SDB: `${AssetsBase}/sdb`,
    SOUNDS: `${AssetsBase}/sounds`,
    WEAR: `${AssetsBase}/wear`,

    LEVEL_IMAGE: (levelPack: string) => `${Paths.LEVELS}/pack/${levelPack}/bitmaps/layer.jpg`,
    LEVEL_MININAP: (levelPack: string) => `${Paths.LEVELS}/pack/${levelPack}/bitmaps/minimap.csx`,
    LEVEL_SDB: (level: string, levelType: LevelType) => `${Paths.LEVELS}/${levelType}/${level}/${level}.sdb`,
    LEVEL_SEF: (level: string, levelType: LevelType) => `${Paths.LEVELS}/${levelType}/${level}/${level}.sef`,
    LEVEL_LAO: (levelPack: string) => `${Paths.LEVELS}/pack/${levelPack}/data/animated/${levelPack}.lao`,
    LEVEL_ANIMATION: (level: string, index: number) => `${Paths.LEVELS}/pack/${level}/bitmaps/animated/anim_${index}.csx`,
    LEVEL_SCRIPT: (level: string, levelType: LevelType, scriptFileName: string) => `${Paths.LEVELS}/${levelType}/${level}/scripts/${scriptFileName}`
};
